var chatOpen = false;



